import logo from "./logo.svg";
import "./App.css";
import "./AddForm.css";
import "./Main.css";

import Main from "./component/Main";

function App() {
  return (
    <>
      <Main />
    </>
  );
}

export default App;
